/**
 * Modelo de Comprobante (anti-duplicado con IA)
 *
 * Registro PERMANENTE (sin TTL, como Transaction) de cada imagen de comprobante
 * que un cliente envía por el chat. Una IA (Claude vision) lee la imagen, decide
 * si es un comprobante y extrae los datos clave. Con la "huella" (dedupeKey) se
 * detecta si un comprobante ya fue usado por OTRO usuario (reutilización/estafa).
 *
 * La colección es nueva → no requiere migración. La detección sólo corre si está
 * configurada la ANTHROPIC_API_KEY (ver src/services/comprobanteAiService.js);
 * si no, no se crea ningún registro y nada se rompe.
 */
const mongoose = require('mongoose');

const comprobanteSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true },
  // Cliente que envió la imagen
  userId: { type: String, index: true },
  username: { type: String, index: true, trim: true },
  // id del Message de tipo 'image' que lo originó (para enlazar al chat)
  messageId: { type: String, default: null },

  // Resultado del análisis de IA
  isComprobante: { type: Boolean, default: false, index: true },
  aiConfidence: { type: Number, default: 0 }, // 0..1

  // Datos extraídos del comprobante (los que la IA pudo leer)
  operationNumber: { type: String, default: null, trim: true },
  coelsaId: { type: String, default: null, trim: true, index: true }, // #999: ID COELSA de la transferencia (cruce exacto con el banco)
  originCuit: { type: String, default: null, trim: true },          // #999: CUIT/CUIL de quien envía (sólo dígitos)
  amount: { type: Number, default: null },
  originHolder: { type: String, default: null, trim: true }, // titular / origen
  originCbu: { type: String, default: null, trim: true },    // CBU/CVU/alias origen
  destHolder: { type: String, default: null, trim: true },   // titular / destino (quién recibe)
  destCbu: { type: String, default: null, trim: true },      // CBU/CVU/alias destino (a quién se envió)
  bank: { type: String, default: null, trim: true },
  paymentDate: { type: String, default: null, trim: true },  // fecha/hora tal como figura
  rawText: { type: String, default: null },                  // texto crudo leído (debug)

  // Huella para detectar duplicados. Se arma con el N° de operación normalizado;
  // si no hay, con un combo monto|cbu|fecha. Indexada para búsqueda rápida.
  dedupeKey: { type: String, default: null, index: true },
  // Hash SHA-256 de la imagen. Si se reenvía LA MISMA imagen, el hash coincide y
  // se detecta como duplicado al 100%, sin depender de cómo la IA leyó los datos
  // (la lectura OCR puede variar entre envíos). Sólo se calcula para imágenes
  // base64 (data:) — el caso típico de capturas; para URLs https queda null.
  imageHash: { type: String, default: null, index: true },

  // Estado del análisis
  status: {
    type: String,
    enum: ['unique', 'duplicate', 'not_comprobante', 'no_key', 'error'],
    default: 'unique',
    index: true
  },
  // Si es duplicado, a quién pertenece el comprobante ORIGINAL
  duplicateOfUserId: { type: String, default: null },
  duplicateOfUsername: { type: String, default: null },
  duplicateOfComprobanteId: { type: String, default: null },

  // Matcheo con el banco con API (hgcash) → carga automática
  toApiBank: { type: Boolean, default: false }, // el destino es el CBU del banco con API
  bankMatchStatus: {
    type: String,
    // awaiting_platform / redirected: multi-plataforma (2026-10-16) — espejo del BankMovement matcheado.
    enum: ['none', 'pending', 'claiming', 'shadow_matched', 'auto_charged', 'manual_charged', 'matched', 'duplicate', 'needs_review', 'awaiting_platform', 'redirected'],
    default: 'none',
    index: true
  },
  matchedMovementId: { type: String, default: null }, // movementId de BankMovement matcheado
  autoCharged: { type: Boolean, default: false },

  // Meta
  model: { type: String, default: null },        // modelo de IA que lo analizó
  errorReason: { type: String, default: null },  // si status==='error'
  // #376: COLA DE REVISIÓN ("Cargas pendientes" del panel). none = no aplica (duplicado / no comprobante);
  // pending = esperando acreditación (automática o del agente); confirmed = cargado (auto | manual);
  // rejected = el agente lo rechazó (el cliente recibió el motivo).
  reviewStatus: { type: String, enum: ['none', 'pending', 'confirmed', 'rejected'], default: 'none', index: true },
  reviewQueuedAt: { type: Date, default: null },
  reviewEscalatedAt: { type: Date, default: null },   // cuándo se le avisó al cliente "pendiente, un agente la revisa"
  reviewEscalateReason: { type: String, default: null },
  reviewResolution: { type: String, default: null },  // 'auto' | 'manual' | 'rejected'
  reviewedBy: { type: String, default: null },
  reviewedAt: { type: Date, default: null },
  reviewNote: { type: String, default: null },
  reviewTxId: { type: String, default: null },
  // #1010: IA caída + cliente de confianza ⇒ se acreditó sin leer (con la transferencia de su cuenta de siempre) y se re-revisa cuando vuelve la IA.
  trustedFallback: { type: Boolean, default: false },
  aiRetryPending: { type: Boolean, default: false, index: true },
  aiRetries: { type: Number, default: 0 },
  aiRecheck: { type: mongoose.Schema.Types.Mixed, default: null },
  shiftReview: { type: mongoose.Schema.Types.Mixed, default: null }, // #1010: revisión del de turno (Para revisar)
  createdAt: { type: Date, default: Date.now, index: true }
}, {
  timestamps: true
});

// Búsqueda de duplicados: por huella, sólo entre los que son comprobantes reales.
comprobanteSchema.index({ dedupeKey: 1, isComprobante: 1 });

comprobanteSchema.index({ reviewStatus: 1, createdAt: 1 }); // #957: cola de Cargas pendientes
module.exports = mongoose.models['Comprobante'] || mongoose.model('Comprobante', comprobanteSchema);
